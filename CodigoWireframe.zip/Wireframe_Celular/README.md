TITULO: FARFAN
![LOGO](https://github.com/user-attachments/assets/46897992-fe52-45de-be35-1f017f5fda46)
ESLOGAN: Para músicos con talento y afán, usa la agenda Farfan
